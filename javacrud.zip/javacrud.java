package com.plyd.java;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import net.proteanit.sql.DbUtils;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.BorderLayout;

public class javacrud {

    private JFrame frame;
    private JTextField textBookName;
    private JTextField textEdition;
    private JTextField textPrice;
    private JTextField textBookID;
    private JTable table;
    private Connection con;
    private PreparedStatement pst;
    private ResultSet ra;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    javacrud window = new javacrud();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public javacrud() {
        Connect();  
        initialize();
        table_load();
    }

    /**
     * Connect to MySQL Database.
     */
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javacrud", "root", "root");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Database Connection Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    /**
     * Load data into the JTable.
     */
    public void table_load() {
        try {
            pst = con.prepareStatement("SELECT * FROM book");
            ra = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(ra));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading table data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setSize(new Dimension(50, 50));
        frame.getContentPane().setBackground(new Color(255, 204, 255));
        frame.getContentPane().setLayout(null);

        JLabel lblTitle = new JLabel("Book Shop");
        lblTitle.setForeground(new Color(64, 0, 64));
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 33));
        lblTitle.setBounds(474, 10, 305, 49);
        frame.getContentPane().add(lblTitle);

      JPanel Register = new JPanel();
      Register.setForeground(new Color(255, 0, 0));
        Register.setBounds(22, 91, 518, 399);
        frame.getContentPane().add(Register);
        Register.setLayout(null);        Register.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), "Registration", TitledBorder.LEADING, TitledBorder.TOP, new Font("Tahoma", Font.BOLD, 20), Color.BLACK));  
Register.setFont (new Font("Tahoma",Font.PLAIN,20));
frame.getContentPane().add(Register);
      
        

        JLabel lblBookName = new JLabel("Book Name");
        lblBookName.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblBookName.setBounds(42, 76, 120, 42);
        Register.add(lblBookName);

        JLabel lblEdition = new JLabel("Edition");
        lblEdition.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblEdition.setBounds(42, 177, 109, 56);
        Register.add(lblEdition);

        JLabel lblPrice = new JLabel("Price");
        lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblPrice.setBounds(42, 293, 120, 42);
        Register.add(lblPrice);

        textBookName = new JTextField();
        textBookName.setFont(new Font("Tahoma", Font.PLAIN, 15));
        textBookName.setBounds(172, 86, 264, 32);
        Register.add(textBookName);

        textEdition = new JTextField();
        textEdition.setFont(new Font("Tahoma", Font.PLAIN, 15));
        textEdition.setBounds(172, 194, 264, 32);
        Register.add(textEdition);

        textPrice = new JTextField();
        textPrice.setFont(new Font("Tahoma", Font.PLAIN, 15));
        textPrice.setBounds(172, 303, 264, 32);
        Register.add(textPrice);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(560, 91, 667, 482);
        frame.getContentPane().add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        JPanel panel_1 = new JPanel();
        panel_1.setBounds(22, 590, 511, 83);
        frame.getContentPane().add(panel_1);
        panel_1.setLayout(null);
       

        frame.setBounds(100, 100, 1267, 733);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel lblBookID = new JLabel("Book ID");
        lblBookID.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblBookID.setBounds(29, 24, 102, 25);
        panel_1.add(lblBookID);

        textBookID = new JTextField();
        textBookID.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String id = textBookID.getText();
                try {
                    pst = con.prepareStatement("select name, edition, price from book where id = ?");
                    pst.setString(1, id);
                    ResultSet rs = pst.executeQuery();
                    if (rs.next() == true) {
                        String name = rs.getString(1);
                        String edition = rs.getString(2);
                        String price = rs.getString(3);
                        textBookName.setText(name);
                        textEdition.setText(edition);
                        textPrice.setText(price);
                    } else {
                        textBookName.setText("");
                        textEdition.setText("");
                        textPrice.setText("");
                    }
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });
        textBookID.setBounds(141, 18, 330, 45);
        panel_1.add(textBookID);

        JButton btnClear = new JButton("Clear");
        btnClear.setForeground(new Color(64, 0, 64));
        btnClear.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnClear.setBounds(738, 600, 155, 73);
        frame.getContentPane().add(btnClear);

        // 🔹 Save Button Action (Insert Data)
        JButton btnSave = new JButton("Save");
        btnSave.setForeground(new Color(64, 0, 64));
        btnSave.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnSave.setBounds(25, 500, 155, 73);
        frame.getContentPane().add(btnSave);
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bname = textBookName.getText();
                String edition = textEdition.getText();
                String price = textPrice.getText();

                try {
                    pst = con.prepareStatement("INSERT INTO book (name, edition, price) VALUES (?, ?, ?)");
                    pst.setString(1, bname);
                    pst.setString(2, edition);
                    pst.setString(3, price);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Record Added");
                    table_load();
                    textBookName.setText("");
                    textEdition.setText("");
                    textPrice.setText("");
                    textBookName.requestFocus();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        

        JButton btnupdate = new JButton("Update");
        btnupdate.setForeground(new Color(64, 0, 64));
        btnupdate.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnupdate.setBounds(560, 600, 155, 73);
        frame.getContentPane().add(btnupdate);

        btnupdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bname = null, edition = null, price = null, bid = null;
                // fetching data from input box
                String bname1 = textBookName.getText();
                String edition1 = textEdition.getText();
                String price1 = textPrice.getText();
                String bid1 = textBookID.getText();
                try {
                    // updating the data from input box
                    pst = con.prepareStatement("update book set name=?, edition=?, price=? where id=?");
                    pst.setString(1, bname1);
                    pst.setString(2, edition1);
                    pst.setString(3, price1);
                    pst.setString(4, bid1);
                    pst.executeUpdate();
                    // show message
                    JOptionPane.showMessageDialog(null, "Record Updated");
                    // display updated data
                    table_load();
                    // clear input boxes
                    textBookName.setText("");
                    textEdition.setText("");
                    textPrice.setText("");
                    textBookID.setText(null);
                    textBookName.requestFocus();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        JButton btndelete = new JButton("Delete");
        btndelete.setForeground(new Color(64, 0, 64));
        btndelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btndelete.setBounds(385, 500, 155, 73);
        frame.getContentPane().add(btndelete);
        btndelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bid;
                bid = textBookID.getText();
                if (bid != null) {
                    try {
                        // if id is not null, delete that data from database
                        pst = con.prepareStatement("delete from book where id = ?");
                        pst.setString(1, bid);
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Record Deleted");
                        // display data in table
                        table_load();
                        // clear input boxes
                        textBookName.setText("");
                        textEdition.setText("");
                        textPrice.setText("");
                        textBookID.setText(null);
                        textBookName.requestFocus();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });

        JButton btnExit = new JButton("Exit");
        btnExit.setForeground(new Color(64, 0, 64));
        btnExit.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnExit.setBounds(207, 500, 155, 73);
        frame.getContentPane().add(btnExit);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        // 🔹 Clear Button Action (Clears Book ID Field)

        btnClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textBookName.setText("");
                textEdition.setText("");
                textPrice.setText("");
                textBookID.setText(null);
                textBookName.requestFocus();
            }
        });
    }
}
